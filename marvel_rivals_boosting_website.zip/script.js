function orderBoost(service, price) {
    alert("You have ordered the " + service + " boost for $" + price + "!");
}
